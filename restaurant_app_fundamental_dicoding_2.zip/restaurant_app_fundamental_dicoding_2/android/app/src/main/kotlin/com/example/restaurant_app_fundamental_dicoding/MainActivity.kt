package com.example.restaurant_app_fundamental_dicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
